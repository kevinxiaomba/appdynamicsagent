$(function() {
    $( "#exampleTabs" ).tabs({ collapsible: true });
});